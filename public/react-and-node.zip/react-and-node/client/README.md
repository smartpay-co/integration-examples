## How to Build Front-end Bundle

Install dependencies:

```bash
yarn install
```

Fill the API key to replace `<YOUR_PUBLIC_API_KEY>` in `App.js`

Build:

```bash
yarn build
```
