### Client

```shell
npx serve -p 3080 build
```
