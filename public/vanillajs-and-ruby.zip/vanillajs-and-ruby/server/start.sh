#!/bin/sh

gem install bundler && bundle install --quiet && ruby server.rb