go get && go run main.go
