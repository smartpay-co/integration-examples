## How to Start the Server

Install dependencies:

```bash
pip install -r requirements.txt
```

Start dev server:

```bash
FLASK_APP=server flask run
```
