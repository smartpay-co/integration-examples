### Backend

```shell
npm install && npm run start
```
