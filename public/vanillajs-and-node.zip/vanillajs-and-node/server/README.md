### Backend

```shell
yarn && yarn start
```