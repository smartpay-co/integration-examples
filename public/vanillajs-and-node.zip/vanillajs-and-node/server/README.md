### Server

```shell
npm install && npm run start
```
