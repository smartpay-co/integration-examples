## How to Start the Server

Install dependencies:

```bash
yarn install
```

Fill the API key to replace `<YOUR_PRIVATE_API_KEY>` and `<YOUR_PUBLIC_API_KEY>` in `server.js`

Start dev server:

```bash
yarn start
```
