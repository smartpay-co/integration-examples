#!/bin/sh

gem install bundler && bundle install && ruby server.rb