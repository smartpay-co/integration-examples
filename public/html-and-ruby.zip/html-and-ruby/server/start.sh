#!/bin/sh

gem install bundler --silent && bundle install --quiet && ruby server.rb