#!/bin/sh

npm install --no-fund --no-audit && npm run start