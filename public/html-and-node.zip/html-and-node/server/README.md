## How to Start the Server

Install dependencies:

```bash
yarn install
```

Start dev server:

```bash
yarn start
```
