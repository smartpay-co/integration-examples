module.exports = {
  /**
   * This method returns current order reference in the merchant's system
   */
  get() {
    return 'order_ref_1234567';
  },
};
