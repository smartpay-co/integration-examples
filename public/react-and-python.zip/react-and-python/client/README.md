### Frontend (pre-bundled)

```shell
npx serve -p 8080 build
```
