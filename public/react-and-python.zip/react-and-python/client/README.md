## How to Build Front-end Bundle

Install dependencies:

```bash
yarn install
```

Build:

```bash
yarn build
```
