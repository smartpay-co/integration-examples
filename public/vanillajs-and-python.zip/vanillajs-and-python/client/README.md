### Frontend (pre-bundled)

```shell
npm i -g serve # or yarn global add serve
serve -p 8080 build
```